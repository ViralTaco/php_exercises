<?php 
/**
 * This file contains the model for the user
 * 
 * @author: Capobianco Anthony 
 * 
 * @license: SPDX License Identifier: MIT
 * Copyright © 2020 Capobianco Anthony
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of 
 * this software and associated documentation files (the "Software"), to deal in the 
 * Software without restriction, including without limitation the rights to use, copy, 
 * modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
 * and to permit persons to whom the Software is furnished to do so, 
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next paragraph) 
 * shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
require_once realpath(__DIR__."/constants.php");
require_once SQL_PHP;
require_once USEREXCEPTION_PHP;

class User {
  public bool $is_connected = false;
  public string $connection_id = "";
  public string $nick;
  
  private string $user_id;
  private string $password_hash; 
  private bool $is_valid_password;

// constructor:
  public function __construct(string $user, string $plaintext_pass) {
    $this->$nick = $user;
    $this->$password_hash = password_hash($plaintext_pass, PASSWORD_ARGON2I);
  }
  
// getters: 
  public function get_user_id() : string {
    if (!isset($this->$user_id)) {
      throw new InvalidUserIdException("User ID not set.");
    }
    return $this->$user_id;
  }

// public methods:
  public function check_pass() : int {
    $preped = $conn->prepare("SELECT `id` FROM `accounts`
                              WHERE `accounts`.`nick` IS ?
                                AND `accounts`.`pass` IS ?;");
    if ($preped->execute([$this->$nick, $this->$password_hash])) {
      $id = 0;
      while ($row = $preped->fetch()) {
        $id = $row;
      }
      return $id;
    } 
    return -1;
  }
  
  public function connect() : void {
    if ($this->$is_connected) {
      throw new UserAlreadyConnectedException("This user is already connected.");
    }
    // Not already connected, continue. 
    $pass_check_returned = $this->check_pass();
    if ($pass_check_returned == -1) {
      throw new InvalidPasswordException("Wrong password.");
    } else {
      $this->$user_id = $pass_check_returned;
      $this->$is_valid_password = true;
    }
    
    $now = new DateTime();
    $this->$connection_id = hash('sha256', $nick.$now->format('Y-m-d H:i:s'));
    
    $insert = $conn->prepare("INSERT INTO `sessions` (`id`, `account_id`)
                              VALUES (:connection_id, :id);");
    $insert->bindParam(":connection_id", $this->$connection_id);
    $insert->bindParam(":id", $this->$user_id);
    $insert->execute();
    
    session_register($this->$connection_id);
    $this->$is_connected = true;
  }
  
  public function disconnect() : void {
    if (!$this->$is_connected) {
      throw new UserNotConnectedException("This user is not connected.");
    }
    // User connected, keep going
    $remove = $conn->prepare("DELETE * FROM `sessions`
                              WHERE `sessions`.`id` IS ?
                                AND `sessions`.`account_id` IS ?;");
    if (!$remove->execute([$this->$connection_id, $this->$user_id])) {
      throw new CannotDisconnectException("Could not close session: "
                                         .$this->$connection_id);
    }
    
    msession_destroy($this->$connection_id);
    $this->$connection_id = "";
    $this->$is_connected = false;
    $this->$is_valid_password = false;
  }
}
